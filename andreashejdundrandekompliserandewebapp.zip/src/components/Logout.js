import firebase, { auth, provider } from '../firebase';

